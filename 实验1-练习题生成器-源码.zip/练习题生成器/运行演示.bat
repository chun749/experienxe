@echo off
set PATH=%SystemRoot%\System32;%SystemRoot%;%PATH%
chcp 936 >nul
mode con: cols=108 lines=42
title ExerciseGen - Interactive Demo
cd /d "%~dp0"
cls
"C:\Program Files\Java\jdk1.8.0_111\bin\java.exe" -cp out com.exercise.Main
echo.
pause