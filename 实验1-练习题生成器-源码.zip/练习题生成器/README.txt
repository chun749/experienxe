练习题生成器 —— 软件构造 实验1
========================================

一、实验内容
按实验要求实现一个四则运算练习题生成程序：每道题由三个（1~99 的）正整数与两个运算符组成，
中间结果与最终结果也是 1~99 的正整数，除法必须整除；题目数量与每行列数可设定，
结果保存为 CSV 文件；核心逻辑用 JUnit 做单元测试。

二、目录说明
  src/main/java/com/exercise/   主程序（22 个类）
      core/      运算符抽象与出题：Operator 及加、减、乘、除四个实现，Question，
                 GeneratorConfig，RandomSource，QuestionFactory，QuestionGenerator
      export/    CSV 格式化与写出：QuestionCsvFormatter、FileCsvWriter
      service/   业务编排：ExerciseService、ExerciseResult
      ui/        控制台交互：ConsoleInput、Main
  src/test/java/com/exercise/   单元测试（7 个测试类，47 个用例）
  lib/                          junit-4.13.2.jar、hamcrest-core-1.3.jar
  docs/                         UML 类图、运行截图
  exercises.csv                 示例输出（30 题、每行 5 列）
  exercises_答案.csv            示例输出的答案文件

三、编译与运行（需要 JDK 1.8 及以上）
  1. 编译主程序
     javac -encoding UTF-8 -d out (src/main/java 下的全部 .java，或用 IDE 直接打开项目)

  2. 交互模式运行
     java -cp out com.exercise.Main

  3. 命令行批量运行
     java -cp out com.exercise.Main 30 5 exercises.csv true
     参数依次为：题目数量（1~200）、每行列数（1~20）、题目文件路径、
     是否同时生成答案文件（true/false，可省略）

四、运行单元测试
  javac -encoding UTF-8 -d test-out -cp "out;lib/junit-4.13.2.jar;lib/hamcrest-core-1.3.jar" (src/test/java 下的全部 .java)
  java -cp "out;test-out;lib/junit-4.13.2.jar;lib/hamcrest-core-1.3.jar" org.junit.runner.JUnitCore ^
       com.exercise.core.OperatorTest com.exercise.core.QuestionTest ^
       com.exercise.core.GeneratorConfigTest com.exercise.core.RandomQuestionFactoryTest ^
       com.exercise.core.UniqueQuestionGeneratorTest com.exercise.export.QuestionCsvFormatterTest ^
       com.exercise.service.ExerciseServiceTest

  也可以直接双击 运行测试.bat（Windows）。

五、说明
  * 生成的 CSV 为 UTF-8（带 BOM），Excel 双击打开不会乱码；每行单元格数即设定的列数。
  * 除法优先取一位数除数（2~9），不会出现“÷1”“×1”这类题目。
  * 控制台输入非法（非整数、超出范围）时给出提示并重新读取，不会退出程序。
