@echo off
set PATH=%SystemRoot%\System32;%SystemRoot%;%PATH%
chcp 936 >nul
mode con: cols=100 lines=18
title ExerciseGen - JUnit Test
cd /d "%~dp0"
cls
"C:\Program Files\Java\jdk1.8.0_111\bin\java.exe" -cp "out;test-out;lib\junit-4.13.2.jar;lib\hamcrest-core-1.3.jar" org.junit.runner.JUnitCore com.exercise.core.OperatorTest com.exercise.core.QuestionTest com.exercise.core.GeneratorConfigTest com.exercise.core.RandomQuestionFactoryTest com.exercise.core.UniqueQuestionGeneratorTest com.exercise.export.QuestionCsvFormatterTest com.exercise.service.ExerciseServiceTest
echo.
pause