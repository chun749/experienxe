package com.exercise.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

/**
 * 出题工厂单元测试：合法性、四则运算分布与异常路径。
 */
public class RandomQuestionFactoryTest {

    private static final int MIN = GeneratorConfig.MIN_VALUE;
    private static final int MAX = GeneratorConfig.MAX_VALUE;

    private QuestionFactory newFactory() {
        return new RandomQuestionFactory(new JavaRandomSource(), Operators.all(), 1000);
    }

    @Test
    public void 生成的题目必须满足全部取值约束() {
        QuestionFactory factory = newFactory();
        for (int i = 0; i < 500; i++) {
            Question question = factory.create();
            assertNotNull(question);
            assertTrue("题目越界：" + question.text(), question.isWithin(MIN, MAX));
            assertTrue(question.getFirst() >= MIN && question.getFirst() <= MAX);
            assertTrue(question.getSecond() >= MIN && question.getSecond() <= MAX);
            assertTrue(question.getThird() >= MIN && question.getThird() <= MAX);
        }
    }

    @Test
    public void 加减乘除应均衡出现() {
        QuestionFactory factory = newFactory();
        Map<Operator, Integer> counts = new HashMap<Operator, Integer>();
        for (Operator operator : Operators.all()) {
            counts.put(operator, 0);
        }
        int total = 400;
        for (int i = 0; i < total; i++) {
            Question question = factory.create();
            Operator first = question.getFirstOperator();
            counts.put(first, counts.get(first) + 1);
        }
        // 均匀随机选择两个运算符，每种运算符预期出现约 25%；放宽到 12% 以避免偶发波动
        int lowBound = (int) (total * 0.12);
        for (Map.Entry<Operator, Integer> entry : counts.entrySet()) {
            assertTrue(entry.getKey().symbol() + " 出现次数过少：" + entry.getValue(),
                    entry.getValue() >= lowBound);
        }
    }

    @Test
    public void 固定随机源应产生可重复的题目() {
        Question first = new RandomQuestionFactory(new FixedRandomSource(3, 7, 2, 5, 9), Operators.all(), 1000).create();
        Question second = new RandomQuestionFactory(new FixedRandomSource(3, 7, 2, 5, 9), Operators.all(), 1000).create();
        assertEquals(first, second);
        assertTrue(first.isWithin(MIN, MAX));
    }

    @Test
    public void 参数非法时应拒绝创建工厂() {
        try {
            new RandomQuestionFactory(new JavaRandomSource(), Operators.all(), 0);
            fail("最大尝试次数为 0 时应抛出异常");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("最大尝试次数"));
        }
        try {
            new RandomQuestionFactory(new JavaRandomSource(), Operators.all(), MAX, MIN, 1000);
            fail("取值区间颠倒时应抛出异常");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("取值范围"));
        }
        try {
            new RandomQuestionFactory(null, Operators.all(), 1000);
            fail("随机源为空时应抛出异常");
        } catch (NullPointerException expected) {
            assertNotNull(expected.getMessage());
        }
    }

    @Test
    public void 区间过小无解时应报错而不是死循环() {
        // 区间只有 2~3，乘除法造不出合法题目，工厂应抛出 IllegalStateException 而不是死循环
        QuestionFactory factory = new RandomQuestionFactory(
                new JavaRandomSource(), Operators.all(), 2, 3, 50);
        try {
            factory.create();
            fail("无解区间应抛出异常");
        } catch (IllegalStateException expected) {
            assertTrue(expected.getMessage().contains("仍未生成合法题目"));
        }
    }

    @Test
    public void 生成的题目不应出现除法余数() {
        QuestionFactory factory = newFactory();
        for (int i = 0; i < 200; i++) {
            Question question = factory.create();
            if ("÷".equals(question.getFirstOperator().symbol())) {
                assertTrue("第一次除法不能整除：" + question.text(),
                        question.getFirstOperator().canApply(question.getFirst(), question.getSecond()));
            }
            if ("÷".equals(question.getSecondOperator().symbol())) {
                assertTrue("第二次除法不能整除：" + question.text(),
                        question.getSecondOperator().canApply(question.intermediateValue(), question.getThird()));
            }
            assertFalse(question.value() <= 0);
        }
    }
}
