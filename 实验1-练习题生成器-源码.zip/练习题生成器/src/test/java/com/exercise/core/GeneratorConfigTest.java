package com.exercise.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

/**
 * 生成参数单元测试：合法参数正常构造，非法参数在构造阶段即被拦截。
 */
public class GeneratorConfigTest {

    @Test
    public void 合法参数应正确保存() {
        GeneratorConfig config = new GeneratorConfig(30, 5);
        assertEquals(30, config.getQuestionCount());
        assertEquals(5, config.getColumnsPerRow());
        assertTrue(config.getMaxAttemptsPerQuestion() >= 1);
        assertTrue(config.toString().contains("30"));
    }

    @Test
    public void 题目数量非法时应报错() {
        assertIllegalArgument(0, 5, "题目数量");
        assertIllegalArgument(-3, 5, "题目数量");
        assertIllegalArgument(GeneratorConfig.MAX_QUESTION_COUNT + 1, 5, "题目数量");
    }

    @Test
    public void 列数非法时应报错() {
        assertIllegalArgument(30, 0, "每行列数");
        assertIllegalArgument(30, -1, "每行列数");
        assertIllegalArgument(30, GeneratorConfig.MAX_COLUMNS + 1, "每行列数");
    }

    @Test
    public void 最大尝试次数非法时应报错() {
        try {
            new GeneratorConfig(30, 5, 0);
            fail("最大尝试次数为 0 时应抛出异常");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("最大尝试次数"));
        }
    }

    @Test
    public void 边界值应被接受() {
        GeneratorConfig config = new GeneratorConfig(GeneratorConfig.MAX_QUESTION_COUNT, GeneratorConfig.MAX_COLUMNS);
        assertEquals(GeneratorConfig.MAX_QUESTION_COUNT, config.getQuestionCount());
        assertEquals(GeneratorConfig.MAX_COLUMNS, config.getColumnsPerRow());
        assertEquals(1, new GeneratorConfig(1, 1).getQuestionCount());
    }

    private void assertIllegalArgument(int count, int columns, String keyword) {
        try {
            new GeneratorConfig(count, columns);
            fail("非法参数应抛出异常：" + count + "," + columns);
        } catch (IllegalArgumentException expected) {
            assertTrue("异常信息应包含“" + keyword + "”，实际为：" + expected.getMessage(),
                    expected.getMessage().contains(keyword));
        }
    }
}
