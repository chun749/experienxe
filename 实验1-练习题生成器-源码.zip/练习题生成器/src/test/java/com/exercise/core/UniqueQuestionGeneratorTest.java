package com.exercise.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

/**
 * 去重生成器单元测试。
 */
public class UniqueQuestionGeneratorTest {

    private QuestionGenerator newGenerator() {
        QuestionFactory factory = new RandomQuestionFactory(new JavaRandomSource(), Operators.all(), 1000);
        return new UniqueQuestionGenerator(factory);
    }

    @Test
    public void 应生成指定数量且互不重复的题目() {
        List<Question> questions = newGenerator().generate(30);
        assertEquals(30, questions.size());
        Set<Question> unique = new HashSet<Question>(questions);
        assertEquals("题目出现重复", 30, unique.size());
        for (Question question : questions) {
            assertTrue("题目越界：" + question.text(), question.isWithin(1, 99));
        }
    }

    @Test
    public void 题量为零时应返回空列表() {
        assertTrue(newGenerator().generate(0).isEmpty());
    }

    @Test
    public void 题量为负数时应报错() {
        try {
            newGenerator().generate(-1);
            fail("负数题量应抛出异常");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("负数"));
        }
    }

    @Test
    public void 大批量题目仍应全部合法且不重复() {
        List<Question> questions = newGenerator().generate(200);
        assertEquals(200, questions.size());
        assertEquals(200, new HashSet<Question>(questions).size());
        for (Question question : questions) {
            assertTrue(question.isWithin(1, 99));
        }
    }

    @Test
    public void 工厂为空时应拒绝创建() {
        try {
            new UniqueQuestionGenerator(null);
            fail("工厂为空时应抛出异常");
        } catch (NullPointerException expected) {
            assertTrue(expected.getMessage().contains("题目工厂"));
        }
    }
}
