package com.exercise.core;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * 测试专用随机源：按预先给定的序列返回数值，用完后循环使用。
 *
 * <p>返回值会被映射到调用方要求的区间内，因此测试用例只需关心“结果是否合法”，
 * 不必关心具体数值，同时整个生成过程又是可重复的。</p>
 */
public class FixedRandomSource implements RandomSource {

    private final Deque<Integer> values;
    private final int[] preset;

    public FixedRandomSource(int... values) {
        if (values.length == 0) {
            throw new IllegalArgumentException("预设序列不能为空");
        }
        this.preset = values.clone();
        this.values = new ArrayDeque<Integer>();
        for (int value : values) {
            this.values.addLast(value);
        }
    }

    @Override
    public int nextInt(int originInclusive, int boundExclusive) {
        if (originInclusive >= boundExclusive) {
            throw new IllegalArgumentException("区间非法");
        }
        int raw = values.isEmpty() ? originInclusive : values.removeFirst();
        if (values.isEmpty()) {
            for (int value : preset) {
                values.addLast(value);
            }
        }
        int span = boundExclusive - originInclusive;
        int offset = Math.floorMod(raw, span);
        return originInclusive + offset;
    }
}
