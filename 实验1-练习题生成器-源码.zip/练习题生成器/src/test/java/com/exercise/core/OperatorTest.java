package com.exercise.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

/**
 * 运算符单元测试：覆盖四则运算的计算、约束判断、优先级与操作数构造。
 */
public class OperatorTest {

    private static final int MIN = GeneratorConfig.MIN_VALUE;
    private static final int MAX = GeneratorConfig.MAX_VALUE;
    private final RandomSource random = new JavaRandomSource();

    @Test
    public void 加法应返回两数之和() {
        assertEquals(15, new AddOperator().apply(12, 3));
        assertEquals("+", new AddOperator().symbol());
        assertEquals(1, new AddOperator().precedence());
    }

    @Test
    public void 减法应返回两数之差() {
        assertEquals(9, new SubOperator().apply(12, 3));
        assertEquals("-", new SubOperator().symbol());
        assertEquals(1, new SubOperator().precedence());
    }

    @Test
    public void 减数大于被减数时应报错() {
        try {
            new SubOperator().apply(3, 12);
            fail("被减数小于减数时应抛出异常");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("负数"));
        }
        assertFalse(new SubOperator().canApply(3, 12));
        assertTrue(new SubOperator().canApply(12, 3));
    }

    @Test
    public void 乘法应返回两数之积() {
        assertEquals(42, new MulOperator().apply(6, 7));
        assertEquals("×", new MulOperator().symbol());
        assertEquals(2, new MulOperator().precedence());
    }

    @Test
    public void 除法应返回两数之商() {
        assertEquals(4, new DivOperator().apply(24, 6));
        assertEquals("÷", new DivOperator().symbol());
        assertEquals(2, new DivOperator().precedence());
    }

    @Test
    public void 除法不能整除时应报错() {
        try {
            new DivOperator().apply(10, 3);
            fail("不能整除时应抛出异常");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("整除"));
        }
        assertFalse(new DivOperator().canApply(10, 3));
        assertTrue(new DivOperator().canApply(10, 2));
    }

    @Test
    public void 除数为零时应报错() {
        try {
            new DivOperator().apply(10, 0);
            fail("除数为 0 时应抛出异常");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("除数"));
        }
    }

    @Test
    public void 四种运算符构造的操作数都应满足取值约束() {
        for (Operator operator : Operators.all()) {
            for (int round = 0; round < 200; round++) {
                int[] operands = operator.createOperands(MIN, MAX, random);
                assertTrue(operator.symbol() + " 在 1~99 区间内应有解", operands != null);
                int left = operands[0];
                int right = operands[1];
                assertTrue(operator.symbol() + " 左操作数越界：" + left, left >= MIN && left <= MAX);
                assertTrue(operator.symbol() + " 右操作数越界：" + right, right >= MIN && right <= MAX);
                assertTrue(operator.symbol() + " 运算不合法", operator.canApply(left, right));
                int result = operator.apply(left, right);
                assertTrue(operator.symbol() + " 结果越界：" + result, result >= MIN && result <= MAX);
            }
        }
    }

    @Test
    public void 乘除法不应出现一乘一除这类无意义题目() {
        for (int round = 0; round < 200; round++) {
            int[] mulOperands = new MulOperator().createOperands(MIN, MAX, random);
            assertTrue("乘法操作数应不小于 2", mulOperands[0] >= 2 && mulOperands[1] >= 2);
            int[] divOperands = new DivOperator().createOperands(MIN, MAX, random);
            assertTrue("除数应不小于 2", divOperands[1] >= 2);
            assertTrue("除数应优先为一位数", divOperands[1] <= 9);
        }
    }

    @Test
    public void 已知左操作数时应能构造合法的右操作数() {
        for (Operator operator : Operators.all()) {
            for (int left = MIN; left <= MAX; left++) {
                int right = operator.createRightOperand(left, MIN, MAX, random);
                if (right >= 0) {
                    assertTrue("右操作数越界：" + right, right >= MIN && right <= MAX);
                    assertTrue("运算不合法", operator.canApply(left, right));
                    int result = operator.apply(left, right);
                    assertTrue("结果越界：" + result, result >= MIN && result <= MAX);
                }
            }
        }
    }

    @Test
    public void 无法配出右操作数时应返回负一() {
        assertEquals(-1, new AddOperator().createRightOperand(99, MIN, MAX, random));
        assertEquals(-1, new SubOperator().createRightOperand(1, MIN, MAX, random));
        assertEquals(-1, new MulOperator().createRightOperand(99, MIN, MAX, random));
    }
}
