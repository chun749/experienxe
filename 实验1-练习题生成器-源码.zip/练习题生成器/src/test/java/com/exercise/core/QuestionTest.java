package com.exercise.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

/**
 * 题目值对象单元测试：结果计算、括号规则、区间校验。
 */
public class QuestionTest {

    private static final int MIN = GeneratorConfig.MIN_VALUE;
    private static final int MAX = GeneratorConfig.MAX_VALUE;

    @Test
    public void 应按先算前两数再与第三个数运算的顺序求值() {
        Question question = new Question(12, new AddOperator(), 3, new MulOperator(), 4);
        assertEquals(15, question.intermediateValue());
        assertEquals(60, question.value());
    }

    @Test
    public void 混合运算应输出规范的括号() {
        assertEquals("(12 + 3) × 4 =", new Question(12, new AddOperator(), 3, new MulOperator(), 4).text());
        assertEquals("(12 - 3) × 4 =", new Question(12, new SubOperator(), 3, new MulOperator(), 4).text());
        assertEquals("(12 + 3) ÷ 5 =", new Question(12, new AddOperator(), 3, new DivOperator(), 5).text());
    }

    @Test
    public void 同优先级或先乘除时应不加括号() {
        assertEquals("12 × 3 + 4 =", new Question(12, new MulOperator(), 3, new AddOperator(), 4).text());
        assertEquals("12 ÷ 3 + 4 =", new Question(12, new DivOperator(), 3, new AddOperator(), 4).text());
        assertEquals("12 + 3 + 4 =", new Question(12, new AddOperator(), 3, new AddOperator(), 4).text());
        assertEquals("12 × 3 ÷ 4 =", new Question(12, new MulOperator(), 3, new DivOperator(), 4).text());
    }

    @Test
    public void 合法题目应通过区间校验() {
        assertTrue(new Question(12, new AddOperator(), 3, new MulOperator(), 4).isWithin(MIN, MAX));
        assertTrue(new Question(95, new AddOperator(), 3, new AddOperator(), 1).isWithin(MIN, MAX));
    }

    @Test
    public void 结果越界应判定为不合法() {
        // 90 + 5 + 20 = 115，最终结果超过 99
        assertFalse(new Question(90, new AddOperator(), 5, new AddOperator(), 20).isWithin(MIN, MAX));
        // 90 × 5 = 450，中间结果越界
        assertFalse(new Question(90, new MulOperator(), 5, new AddOperator(), 1).isWithin(MIN, MAX));
        // 操作数本身越界
        assertFalse(new Question(120, new AddOperator(), 1, new AddOperator(), 1).isWithin(MIN, MAX));
    }

    @Test
    public void 除法不能整除或减法结果为非正数时应判定为不合法() {
        assertFalse(new Question(10, new DivOperator(), 3, new AddOperator(), 1).isWithin(MIN, MAX));
        assertFalse(new Question(12, new SubOperator(), 12, new AddOperator(), 5).isWithin(MIN, MAX));
    }

    @Test
    public void 相同算式应视为重复题目() {
        Question first = new Question(12, new AddOperator(), 3, new MulOperator(), 4);
        Question second = new Question(12, new AddOperator(), 3, new MulOperator(), 4);
        Question other = new Question(12, new AddOperator(), 3, new MulOperator(), 5);
        assertEquals(first, second);
        assertEquals(first.hashCode(), second.hashCode());
        assertFalse(first.equals(other));
    }

    @Test
    public void 运算符为空时应拒绝创建() {
        try {
            new Question(1, null, 2, new AddOperator(), 3);
            fail("第一个运算符为空时应抛出异常");
        } catch (NullPointerException expected) {
            assertTrue(expected.getMessage().contains("第一个运算符"));
        }
    }
}
