package com.exercise.export;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.exercise.core.JavaRandomSource;
import com.exercise.core.Operators;
import com.exercise.core.Question;
import com.exercise.core.QuestionFactory;
import com.exercise.core.RandomQuestionFactory;

/**
 * CSV 格式化单元测试：行数、列数、单元格内容与转义规则。
 */
public class QuestionCsvFormatterTest {

    private CsvFormatter formatter;
    private List<Question> questions;

    @Before
    public void setUp() {
        formatter = new QuestionCsvFormatter();
        QuestionFactory factory = new RandomQuestionFactory(new JavaRandomSource(), Operators.all(), 1000);
        questions = new ArrayList<Question>();
        for (int i = 0; i < 30; i++) {
            questions.add(factory.create());
        }
    }

    @Test
    public void 三十道题每行五列应输出六行() {
        String content = formatter.format(questions, 5);
        String[] lines = content.split("\\R");
        assertEquals(6, lines.length);
        for (String line : lines) {
            assertEquals("每行应有 5 个单元格", 5, line.split(",").length);
        }
    }

    @Test
    public void 单元格应包含题号与算式() {
        String content = formatter.format(questions, 5);
        String firstCell = content.split("\\R")[0].split(",")[0];
        assertTrue("首个单元格应带题号", firstCell.startsWith("1. "));
        assertTrue("单元格应以等号结尾", firstCell.endsWith("="));
    }

    @Test
    public void 最后一行不足时应按实际题量输出() {
        String content = formatter.format(questions.subList(0, 7), 3);
        String[] lines = content.split("\\R");
        assertEquals(3, lines.length);
        assertEquals(3, lines[0].split(",").length);
        assertEquals(1, lines[2].split(",").length);
    }

    @Test
    public void 答案格式应只包含题号与结果() {
        String content = formatter.formatAnswers(questions.subList(0, 10), 5);
        String[] cells = content.split("\\R")[0].split(",");
        for (int i = 0; i < cells.length; i++) {
            assertTrue(cells[i].startsWith((i + 1) + ". "));
            assertTrue("答案单元格不应包含等号：" + cells[i], !cells[i].contains("="));
        }
    }

    @Test
    public void 非法列数应报错() {
        try {
            formatter.format(questions, 0);
            fail("列数为 0 时应抛出异常");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("每行列数"));
        }
    }

    @Test
    public void 题目列表为空应报错() {
        try {
            formatter.format(null, 5);
            fail("题目列表为空时应抛出异常");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("题目列表"));
        }
    }

    @Test
    public void 题量小于列数时应只输出一行() {
        String content = formatter.format(questions.subList(0, 3), 5);
        String[] lines = content.split("\\R");
        assertEquals(1, lines.length);
        assertEquals(3, lines[0].split(",").length);
    }
}
