package com.exercise.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import com.exercise.core.GeneratorConfig;
import com.exercise.core.JavaRandomSource;
import com.exercise.core.Operators;
import com.exercise.core.QuestionFactory;
import com.exercise.core.QuestionGenerator;
import com.exercise.core.RandomQuestionFactory;
import com.exercise.core.UniqueQuestionGenerator;
import com.exercise.export.CsvFormatter;
import com.exercise.export.CsvWriter;
import com.exercise.export.FileCsvWriter;
import com.exercise.export.QuestionCsvFormatter;

/**
 * 业务编排单元测试：验证生成、格式化、写文件的全流程与边界情况。
 */
public class ExerciseServiceTest {

    @Rule
    public TemporaryFolder folder = new TemporaryFolder();

    private ExerciseService newService() {
        QuestionFactory factory = new RandomQuestionFactory(new JavaRandomSource(), Operators.all(), 1000);
        QuestionGenerator generator = new UniqueQuestionGenerator(factory);
        CsvFormatter formatter = new QuestionCsvFormatter();
        CsvWriter writer = new FileCsvWriter();
        return new ExerciseService(generator, formatter, writer);
    }

    @Test
    public void 应生成题目文件与答案文件() throws Exception {
        File questionFile = new File(folder.getRoot(), "练习题.csv");
        File answerFile = new File(folder.getRoot(), "练习题_答案.csv");
        ExerciseResult result = newService().generate(new GeneratorConfig(30, 5), questionFile, answerFile);

        assertEquals(30, result.getQuestionCount());
        assertEquals(5, result.getColumnsPerRow());
        assertTrue(questionFile.exists());
        assertTrue(answerFile.exists());
        assertEquals(answerFile, result.getAnswerFile());
        assertNotNull(result.getPreviewLines());
        assertEquals(3, result.getPreviewLines().size());

        List<String> lines = Files.readAllLines(questionFile.toPath(), StandardCharsets.UTF_8);
        assertEquals("每行 5 列、共 30 题应输出 6 行", 6, lines.size());
        assertTrue(lines.get(0).startsWith("\uFEFF1. ") || lines.get(0).startsWith("1. "));
    }

    @Test
    public void 不指定答案文件时只生成题目文件() throws Exception {
        File questionFile = new File(folder.getRoot(), "练习题.csv");
        ExerciseResult result = newService().generate(new GeneratorConfig(10, 2), questionFile);
        assertTrue(questionFile.exists());
        assertEquals(null, result.getAnswerFile());
        assertEquals(5, Files.readAllLines(questionFile.toPath(), StandardCharsets.UTF_8).size());
    }

    @Test
    public void 输出文件应为带BOM的UTF8编码() throws Exception {
        File questionFile = new File(folder.getRoot(), "编码.csv");
        newService().generate(new GeneratorConfig(5, 1), questionFile, null);
        byte[] bytes = Files.readAllBytes(questionFile.toPath());
        assertEquals("应以 UTF-8 BOM 开头，便于 Excel 正确识别中文", 0xEF, bytes[0] & 0xFF);
        assertEquals(0xBB, bytes[1] & 0xFF);
        assertEquals(0xBF, bytes[2] & 0xFF);
    }

    @Test
    public void 目录不存在时应自动创建() throws Exception {
        File nested = new File(folder.getRoot(), "a/b/c/练习题.csv");
        newService().generate(new GeneratorConfig(5, 5), nested, null);
        assertTrue(nested.exists());
    }

    @Test
    public void 参数为空时应抛出异常() throws Exception {
        File file = new File(folder.getRoot(), "空.csv");
        try {
            newService().generate(null, file);
        } catch (NullPointerException expected) {
            assertFalse(expected.getMessage() == null);
            return;
        }
        org.junit.Assert.fail("生成参数为空时应抛出异常");
    }
}
