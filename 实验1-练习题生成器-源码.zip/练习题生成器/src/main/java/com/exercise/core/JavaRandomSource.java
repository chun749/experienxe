package com.exercise.core;

import java.util.concurrent.ThreadLocalRandom;

/**
 * 基于 {@link ThreadLocalRandom} 的随机数实现，线程安全且无需共享种子。
 */
public class JavaRandomSource implements RandomSource {

    @Override
    public int nextInt(int originInclusive, int boundExclusive) {
        if (originInclusive >= boundExclusive) {
            throw new IllegalArgumentException(
                    "随机数区间非法：[" + originInclusive + ", " + boundExclusive + ")");
        }
        return ThreadLocalRandom.current().nextInt(originInclusive, boundExclusive);
    }
}
