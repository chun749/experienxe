package com.exercise.core;

import java.util.List;
import java.util.Objects;

/**
 * 构造式出题工厂。
 *
 * <p>出题策略分两步：</p>
 * <ol>
 *   <li>先均匀随机选择两个运算符，保证整张练习卷中加、减、乘、除出现比例均衡；</li>
 *   <li>再按所选运算符的规则<b>反向构造</b>操作数：先由第一个运算符造出合法的中间结果，
 *       再由第二个运算符为中间结果配出第三个操作数，使中间结果与最终结果都落在
 *       [minValue, maxValue] 内。</li>
 * </ol>
 *
 * <p>相比“随机取数 + 事后校验 + 丢弃重试”的盲目抽样，本策略的命中率高，
 * 不会因为乘除法约束强而让练习卷被加减法淹没；最后仍保留一次完整校验作为安全网。</p>
 */
public class RandomQuestionFactory implements QuestionFactory {

    private final RandomSource randomSource;
    private final List<Operator> operators;
    private final int minValue;
    private final int maxValue;
    private final int maxAttempts;

    public RandomQuestionFactory(RandomSource randomSource, List<Operator> operators, int maxAttempts) {
        this(randomSource, operators, GeneratorConfig.MIN_VALUE, GeneratorConfig.MAX_VALUE, maxAttempts);
    }

    public RandomQuestionFactory(RandomSource randomSource, List<Operator> operators,
                                 int minValue, int maxValue, int maxAttempts) {
        this.randomSource = Objects.requireNonNull(randomSource, "随机数来源不能为空");
        this.operators = Objects.requireNonNull(operators, "运算符集合不能为空");
        if (operators.isEmpty()) {
            throw new IllegalArgumentException("运算符集合不能为空列表");
        }
        if (minValue < 1 || maxValue <= minValue) {
            throw new IllegalArgumentException("取值范围非法：[" + minValue + ", " + maxValue + "]");
        }
        if (maxAttempts < 1) {
            throw new IllegalArgumentException("最大尝试次数必须大于 0");
        }
        this.minValue = minValue;
        this.maxValue = maxValue;
        this.maxAttempts = maxAttempts;
    }

    @Override
    public Question create() {
        for (int attempt = 0; attempt < maxAttempts; attempt++) {
            Operator firstOperator = randomOperator();
            Operator secondOperator = randomOperator();

            int[] operands = firstOperator.createOperands(minValue, maxValue, randomSource);
            if (operands == null) {
                continue; // 该运算符在当前区间内造不出操作数
            }
            int middle = firstOperator.apply(operands[0], operands[1]);
            int third = secondOperator.createRightOperand(middle, minValue, maxValue, randomSource);
            if (third < 0) {
                continue; // 中间结果太大或太小，第二个运算符配不到合法的第三个数
            }
            Question question = new Question(operands[0], firstOperator, operands[1], secondOperator, third);
            if (question.isWithin(minValue, maxValue)) {
                return question;
            }
        }
        throw new IllegalStateException("连续 " + maxAttempts + " 次尝试仍未生成合法题目，请检查取值范围配置");
    }

    private Operator randomOperator() {
        return operators.get(randomSource.nextInt(0, operators.size()));
    }
}
