package com.exercise.core;

/**
 * 减法运算。
 *
 * <p>实验要求中间结果与最终结果都必须为正整数，因此减法只在“被减数大于减数”时使用，
 * 且差值不小于下限。</p>
 */
public class SubOperator implements Operator {

    @Override
    public String symbol() {
        return "-";
    }

    @Override
    public int apply(int left, int right) {
        if (left < right) {
            throw new IllegalArgumentException("减法结果不能为负数：" + left + "-" + right);
        }
        return left - right;
    }

    @Override
    public boolean canApply(int left, int right) {
        return left >= right;
    }

    @Override
    public int precedence() {
        return 1;
    }

    @Override
    public int[] createOperands(int minValue, int maxValue, RandomSource randomSource) {
        if (maxValue < 2 * minValue) {
            return null;
        }
        // 先定较小的减数，再让被减数至少比它大 minValue，从而保证差值不小于下限
        int right = randomSource.nextInt(minValue, maxValue - minValue + 1);
        int left = randomSource.nextInt(right + minValue, maxValue + 1);
        return new int[] {left, right};
    }

    @Override
    public int createRightOperand(int left, int minValue, int maxValue, RandomSource randomSource) {
        if (left < 2 * minValue) {
            return -1;
        }
        return randomSource.nextInt(minValue, left - minValue + 1);
    }
}
