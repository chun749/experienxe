package com.exercise.core;

import java.util.ArrayList;
import java.util.List;

/**
 * 除法运算。
 *
 * <p>为保证结果与中间结果都是正整数，除法必须整除；除数优先取一位数（2~9），
 * 避免出现“÷1”“÷31”这类没有训练价值的题目。</p>
 */
public class DivOperator implements Operator {

    /** 最小除数，避免“÷1”。 */
    private static final int MIN_DIVISOR = 2;

    /** 除数优先使用的上限（一位数）。 */
    private static final int PREFERRED_MAX_DIVISOR = 9;

    @Override
    public String symbol() {
        return "÷";
    }

    @Override
    public int apply(int left, int right) {
        if (right == 0) {
            throw new IllegalArgumentException("除数不能为 0");
        }
        if (left % right != 0) {
            throw new IllegalArgumentException("除法必须整除：" + left + "÷" + right);
        }
        return left / right;
    }

    @Override
    public boolean canApply(int left, int right) {
        return right != 0 && left % right == 0;
    }

    @Override
    public int precedence() {
        return 2;
    }

    @Override
    public int[] createOperands(int minValue, int maxValue, RandomSource randomSource) {
        int lower = Math.max(minValue, MIN_DIVISOR);
        int divisorUpper = Math.min(PREFERRED_MAX_DIVISOR, maxValue / lower);
        if (divisorUpper < lower) {
            divisorUpper = maxValue / lower;
        }
        if (divisorUpper < lower) {
            return null;
        }
        int divisor = randomSource.nextInt(lower, divisorUpper + 1);

        // 先定除数，再定不小于下限的商，被除数 = 除数 × 商，天然整除
        int quotient = randomSource.nextInt(lower, maxValue / divisor + 1);
        return new int[] {divisor * quotient, divisor};
    }

    @Override
    public int createRightOperand(int left, int minValue, int maxValue, RandomSource randomSource) {
        int lower = Math.max(minValue, MIN_DIVISOR);
        int maxDivisorByValue = left / Math.max(minValue, 1);
        int upper = Math.min(PREFERRED_MAX_DIVISOR, maxDivisorByValue);
        if (upper < lower) {
            upper = Math.min(maxDivisorByValue, maxValue);
        }
        if (upper < lower) {
            return -1;
        }
        // 在候选除数中挑出能整除、且商在区间内的那些，再随机选一个
        List<Integer> candidates = new ArrayList<Integer>();
        for (int divisor = lower; divisor <= upper; divisor++) {
            int quotient = left / divisor;
            if (left % divisor == 0 && quotient >= minValue && quotient <= maxValue) {
                candidates.add(divisor);
            }
        }
        if (candidates.isEmpty()) {
            return -1;
        }
        return candidates.get(randomSource.nextInt(0, candidates.size()));
    }
}
