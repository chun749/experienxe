package com.exercise.core;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 运算符注册表。
 *
 * <p>集中维护系统支持的全部运算符，生成器只面向本注册表取运算符，
 * 后续扩展运算种类时只需在此登记，符合“开闭原则”。</p>
 */
public final class Operators {

    /** 全部可用运算符（不可变集合，避免外部误改）。 */
    private static final List<Operator> ALL = Collections.unmodifiableList(Arrays.asList(
            new AddOperator(),
            new SubOperator(),
            new MulOperator(),
            new DivOperator()));

    private Operators() {
        // 工具类，禁止实例化
    }

    public static List<Operator> all() {
        return ALL;
    }
}
