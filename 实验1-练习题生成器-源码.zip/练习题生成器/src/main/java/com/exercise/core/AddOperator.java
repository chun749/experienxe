package com.exercise.core;

/**
 * 加法运算。
 *
 * <p>操作数均为正整数，结果恒为正整数；只需保证结果不超过上限。</p>
 */
public class AddOperator implements Operator {

    @Override
    public String symbol() {
        return "+";
    }

    @Override
    public int apply(int left, int right) {
        return left + right;
    }

    @Override
    public boolean canApply(int left, int right) {
        return true;
    }

    @Override
    public int precedence() {
        return 1;
    }

    @Override
    public int[] createOperands(int minValue, int maxValue, RandomSource randomSource) {
        if (maxValue < 2 * minValue) {
            return null;
        }
        // 左操作数最大取 maxValue - minValue，保证右操作数至少还能取到 minValue
        int left = randomSource.nextInt(minValue, maxValue - minValue + 1);
        int right = randomSource.nextInt(minValue, maxValue - left + 1);
        return new int[] {left, right};
    }

    @Override
    public int createRightOperand(int left, int minValue, int maxValue, RandomSource randomSource) {
        if (left > maxValue - minValue) {
            return -1;
        }
        return randomSource.nextInt(minValue, maxValue - left + 1);
    }
}
