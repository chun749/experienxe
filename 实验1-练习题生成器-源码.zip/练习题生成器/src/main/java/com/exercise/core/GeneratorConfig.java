package com.exercise.core;

/**
 * 生成参数配置。
 *
 * <p>把“输出数量及格式可设定”的要求收敛为一个配置对象，构造时一次性完成校验，
 * 使非法参数在进入生成流程之前就被拦截，保证系统内部数据始终合法。</p>
 */
public final class GeneratorConfig {

    /** 操作数与结果允许的最小值（正整数）。 */
    public static final int MIN_VALUE = 1;

    /** 操作数与结果允许的最大值（要求“小于 100”，故取 99）。 */
    public static final int MAX_VALUE = 99;

    /** 一次最多生成的题目数量。 */
    public static final int MAX_QUESTION_COUNT = 200;

    /** 一行最多展示的列数。 */
    public static final int MAX_COLUMNS = 20;

    /** 生成单道题目的默认最大尝试次数。 */
    private static final int DEFAULT_MAX_ATTEMPTS = 1000;

    private final int questionCount;
    private final int columnsPerRow;
    private final int maxAttemptsPerQuestion;

    public GeneratorConfig(int questionCount, int columnsPerRow) {
        this(questionCount, columnsPerRow, DEFAULT_MAX_ATTEMPTS);
    }

    public GeneratorConfig(int questionCount, int columnsPerRow, int maxAttemptsPerQuestion) {
        if (questionCount < 1 || questionCount > MAX_QUESTION_COUNT) {
            throw new IllegalArgumentException(
                    "题目数量必须在 " + 1 + " ~ " + MAX_QUESTION_COUNT + " 之间，当前为：" + questionCount);
        }
        if (columnsPerRow < 1 || columnsPerRow > MAX_COLUMNS) {
            throw new IllegalArgumentException(
                    "每行列数必须在 " + 1 + " ~ " + MAX_COLUMNS + " 之间，当前为：" + columnsPerRow);
        }
        if (maxAttemptsPerQuestion < 1) {
            throw new IllegalArgumentException("单题最大尝试次数必须大于 0，当前为：" + maxAttemptsPerQuestion);
        }
        this.questionCount = questionCount;
        this.columnsPerRow = columnsPerRow;
        this.maxAttemptsPerQuestion = maxAttemptsPerQuestion;
    }

    public int getQuestionCount() {
        return questionCount;
    }

    public int getColumnsPerRow() {
        return columnsPerRow;
    }

    public int getMaxAttemptsPerQuestion() {
        return maxAttemptsPerQuestion;
    }

    @Override
    public String toString() {
        return "GeneratorConfig{题目数量=" + questionCount
                + ", 每行列数=" + columnsPerRow
                + ", 单题最大尝试次数=" + maxAttemptsPerQuestion + "}";
    }
}
