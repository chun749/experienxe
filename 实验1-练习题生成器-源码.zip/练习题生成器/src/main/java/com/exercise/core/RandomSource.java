package com.exercise.core;

/**
 * 随机数来源抽象。
 *
 * <p>把随机数产生方式从生成逻辑中剥离出来：生产环境使用 {@link JavaRandomSource}，
 * 单元测试可注入固定序列的实现，从而得到可重复、可断言的生成结果。</p>
 */
public interface RandomSource {

    /**
     * 返回 [originInclusive, boundExclusive) 区间内的随机整数。
     *
     * @throws IllegalArgumentException 当区间非法时抛出
     */
    int nextInt(int originInclusive, int boundExclusive);
}
