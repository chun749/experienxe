package com.exercise.core;

import java.util.Objects;

/**
 * 题目值对象（不可变）。
 *
 * <p>一道题由三个操作数与两个运算符组成，计算顺序固定为 (a op1 b) op2 c，
 * 即先算前两个数，再与第三个数运算，与四则运算的从左到右顺序一致。</p>
 */
public final class Question {

    private final int first;
    private final int second;
    private final int third;
    private final Operator firstOperator;
    private final Operator secondOperator;

    public Question(int first, Operator firstOperator, int second, Operator secondOperator, int third) {
        this.first = first;
        this.second = second;
        this.third = third;
        this.firstOperator = Objects.requireNonNull(firstOperator, "第一个运算符不能为空");
        this.secondOperator = Objects.requireNonNull(secondOperator, "第二个运算符不能为空");
    }

    /** 前两个数的中间结果，例如 (12 + 3) 中的 15。 */
    public int intermediateValue() {
        return firstOperator.apply(first, second);
    }

    /** 题目的最终结果。 */
    public int value() {
        return secondOperator.apply(intermediateValue(), third);
    }

    /**
     * 判断本题是否满足约束：三个操作数、中间结果、最终结果都必须落在 [minValue, maxValue] 区间内，
     * 且两次运算本身合法（减法为正、除法整除）。
     */
    public boolean isWithin(int minValue, int maxValue) {
        if (!firstOperator.canApply(first, second)) {
            return false;
        }
        int middle = firstOperator.apply(first, second);
        if (!secondOperator.canApply(middle, third)) {
            return false;
        }
        int result = secondOperator.apply(middle, third);
        return inRange(first, minValue, maxValue)
                && inRange(second, minValue, maxValue)
                && inRange(third, minValue, maxValue)
                && inRange(middle, minValue, maxValue)
                && inRange(result, minValue, maxValue);
    }

    /**
     * 生成题目的展示文本，例如“(12 + 3) × 4 =”。
     *
     * <p>当第一个运算符优先级低于第二个运算符时，必须给前半部分加括号，
     * 否则算式含义与程序的计算顺序不一致。</p>
     */
    public String text() {
        String left = first + " " + firstOperator.symbol() + " " + second;
        if (firstOperator.precedence() < secondOperator.precedence()) {
            left = "(" + left + ")";
        }
        return left + " " + secondOperator.symbol() + " " + third + " =";
    }

    public int getFirst() {
        return first;
    }

    public int getSecond() {
        return second;
    }

    public int getThird() {
        return third;
    }

    public Operator getFirstOperator() {
        return firstOperator;
    }

    public Operator getSecondOperator() {
        return secondOperator;
    }

    private static boolean inRange(int value, int minValue, int maxValue) {
        return value >= minValue && value <= maxValue;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Question)) {
            return false;
        }
        Question that = (Question) other;
        return first == that.first
                && second == that.second
                && third == that.third
                && firstOperator.symbol().equals(that.firstOperator.symbol())
                && secondOperator.symbol().equals(that.secondOperator.symbol());
    }

    @Override
    public int hashCode() {
        return Objects.hash(first, second, third, firstOperator.symbol(), secondOperator.symbol());
    }

    @Override
    public String toString() {
        return text();
    }
}
