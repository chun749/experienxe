package com.exercise.core;

/**
 * 题目工厂抽象：负责产出一道满足约束的题目。
 *
 * <p>实现类可以更换不同的出题策略（随机出题、从题库抽取等），
 * 生成器无需感知具体策略，符合依赖倒转原则。</p>
 */
public interface QuestionFactory {

    /**
     * 创建一道合法题目。
     *
     * @throws IllegalStateException 在规定次数内无法创建合法题目时抛出
     */
    Question create();
}
