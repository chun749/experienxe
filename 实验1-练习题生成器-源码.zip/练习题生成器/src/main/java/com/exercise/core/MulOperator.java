package com.exercise.core;

/**
 * 乘法运算。
 *
 * <p>两个乘数都取一位数（2~9），避免出现“×31”这类不适合口算的题目；
 * 区间过小时自动放宽，保证在合法取值范围内仍能出题。</p>
 */
public class MulOperator implements Operator {

    /** 乘除法的最小操作数，保证题目有练习价值。 */
    static final int MIN_FACTOR = 2;

    /** 乘除法优先使用的最大操作数（一位数）。 */
    static final int PREFERRED_MAX_FACTOR = 9;

    @Override
    public String symbol() {
        return "×";
    }

    @Override
    public int apply(int left, int right) {
        return left * right;
    }

    @Override
    public boolean canApply(int left, int right) {
        return true;
    }

    @Override
    public int precedence() {
        return 2;
    }

    @Override
    public int[] createOperands(int minValue, int maxValue, RandomSource randomSource) {
        int lower = Math.max(minValue, MIN_FACTOR);
        int leftUpper = Math.min(PREFERRED_MAX_FACTOR, maxValue / lower);
        if (leftUpper < lower) {
            leftUpper = maxValue / lower;
        }
        if (leftUpper < lower) {
            return null;
        }
        int left = randomSource.nextInt(lower, leftUpper + 1);

        int rightUpper = Math.min(PREFERRED_MAX_FACTOR, maxValue / left);
        if (rightUpper < lower) {
            rightUpper = maxValue / left;
        }
        if (rightUpper < lower) {
            return null;
        }
        int right = randomSource.nextInt(lower, rightUpper + 1);
        return new int[] {left, right};
    }

    @Override
    public int createRightOperand(int left, int minValue, int maxValue, RandomSource randomSource) {
        int lower = Math.max(minValue, MIN_FACTOR);
        int upper = Math.min(PREFERRED_MAX_FACTOR, maxValue / left);
        if (upper < lower) {
            upper = maxValue / left;
        }
        if (upper < lower) {
            return -1;
        }
        return randomSource.nextInt(lower, upper + 1);
    }
}
