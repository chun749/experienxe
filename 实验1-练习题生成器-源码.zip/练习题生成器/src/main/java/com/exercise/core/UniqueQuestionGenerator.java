package com.exercise.core;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * 去重题目生成器。
 *
 * <p>在工厂产出的题目基础上做重复校验，保证同一份练习卷中不出现完全相同的算式，
 * 同时通过唯一性比例上限避免陷入死循环。</p>
 */
public class UniqueQuestionGenerator implements QuestionGenerator {

    /** 允许的无效尝试次数相对于目标题量的倍数。 */
    private static final int ATTEMPT_FACTOR = 50;

    private final QuestionFactory questionFactory;

    public UniqueQuestionGenerator(QuestionFactory questionFactory) {
        this.questionFactory = Objects.requireNonNull(questionFactory, "题目工厂不能为空");
    }

    @Override
    public List<Question> generate(int count) {
        if (count < 0) {
            throw new IllegalArgumentException("题目数量不能为负数，当前为：" + count);
        }
        if (count == 0) {
            return new ArrayList<Question>();
        }
        Set<Question> questions = new LinkedHashSet<Question>();
        long attempts = 0;
        long attemptLimit = (long) count * ATTEMPT_FACTOR;
        while (questions.size() < count) {
            if (attempts++ >= attemptLimit) {
                throw new IllegalStateException("已尝试 " + attemptLimit
                        + " 次仍无法生成 " + count + " 道不重复的题目，请减少题目数量");
            }
            questions.add(questionFactory.create());
        }
        return new ArrayList<Question>(questions);
    }
}
