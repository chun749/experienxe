package com.exercise.core;

import java.util.List;

/**
 * 题目生成器抽象。
 */
public interface QuestionGenerator {

    /**
     * 生成指定数量的题目。
     *
     * @param count 题目数量，必须大于等于 0
     * @return 题目列表，长度等于 count
     * @throws IllegalArgumentException 参数非法时抛出
     * @throws IllegalStateException    无法生成足够数量的合法题目时抛出
     */
    List<Question> generate(int count);
}
