package com.exercise.core;

/**
 * 二元运算符抽象。
 *
 * <p>本接口体现了<b>依赖倒转原则（DIP）</b>：生成器与题目等上层代码只依赖本接口，
 * 不依赖任何一个具体运算实现。新增一种运算（如取余）时，只需实现本接口并注册到
 * {@link Operators}，已有代码无需修改。</p>
 *
 * <p>每个实现类只负责一种运算的“计算、校验、构造操作数”，体现了<b>单一职责原则（SRP）</b>，
 * 也把“怎样为某个运算符取到合法操作数”这一知识留在运算符自身，避免上层用 if/else 判断运算类型。</p>
 */
public interface Operator {

    /**
     * 运算符符号，用于题目文本输出，如 +、-、×、÷。
     */
    String symbol();

    /**
     * 计算运算结果。
     *
     * @throws IllegalArgumentException 当操作数不满足该运算的约束时抛出（如除数为 0 或不满足整除）
     */
    int apply(int left, int right);

    /**
     * 判断给定的两个操作数是否满足该运算的约束（减法结果为正、除法整除等）。
     */
    boolean canApply(int left, int right);

    /**
     * 运算符优先级，数值越大优先级越高（加、减为 1，乘、除为 2）。
     */
    int precedence();

    /**
     * 随机构造一组满足该运算约束的操作数，使运算结果落在 [minValue, maxValue] 内。
     *
     * @return 长度为 2 的数组 {左操作数, 右操作数}；当前区间内无解时返回 {@code null}
     */
    int[] createOperands(int minValue, int maxValue, RandomSource randomSource);

    /**
     * 已知左操作数，随机构造一个右操作数，使运算结果落在 [minValue, maxValue] 内。
     *
     * @return 可用的右操作数；不存在时返回 -1
     */
    int createRightOperand(int left, int minValue, int maxValue, RandomSource randomSource);
}
