package com.exercise.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * 控制台输入辅助类。
 *
 * <p>所有输入都带提示、默认值与合法性校验：输入非法时给出明确提示并重新读取，
 * 而不是抛出异常退出程序，保证界面友好与健壮性。</p>
 */
public class ConsoleInput {

    private final BufferedReader reader;

    public ConsoleInput() {
        this.reader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
    }

    /**
     * 读取 [min, max] 区间内的整数，直接回车返回默认值。
     */
    public int readInt(String prompt, int min, int max, int defaultValue) {
        while (true) {
            String line = readLine(prompt);
            if (line.isEmpty()) {
                return defaultValue;
            }
            try {
                int value = Integer.parseInt(line);
                if (value < min || value > max) {
                    System.out.println("[提示] 输入超出范围，请输入 " + min + " ~ " + max + " 之间的整数。");
                    continue;
                }
                return value;
            } catch (NumberFormatException e) {
                System.out.println("[提示] 输入格式不正确，请输入整数。");
            }
        }
    }

    /**
     * 读取非空文本，直接回车返回默认值。
     */
    public String readText(String prompt, String defaultValue) {
        while (true) {
            String line = readLine(prompt);
            if (!line.isEmpty()) {
                return line;
            }
            if (defaultValue != null) {
                return defaultValue;
            }
            System.out.println("[提示] 内容不能为空，请重新输入。");
        }
    }

    /**
     * 读取是/否回答，直接回车返回默认值。
     */
    public boolean readYesNo(String prompt, boolean defaultValue) {
        while (true) {
            String line = readLine(prompt);
            if (line.isEmpty()) {
                return defaultValue;
            }
            String lower = line.toLowerCase();
            if ("y".equals(lower) || "yes".equals(lower) || "是".equals(lower)) {
                return true;
            }
            if ("n".equals(lower) || "no".equals(lower) || "否".equals(lower)) {
                return false;
            }
            System.out.println("[提示] 请输入 y 或 n。");
        }
    }

    private String readLine(String prompt) {
        System.out.print(prompt);
        try {
            String line = reader.readLine();
            return line == null ? "" : line.trim();
        } catch (IOException e) {
            throw new IllegalStateException("读取控制台输入失败：" + e.getMessage(), e);
        }
    }
}
