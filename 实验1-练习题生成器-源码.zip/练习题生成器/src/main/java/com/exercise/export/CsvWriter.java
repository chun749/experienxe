package com.exercise.export;

import java.io.File;
import java.io.IOException;

/**
 * 文件写入抽象。把“写到哪里、用什么编码”与业务逻辑解耦，
 * 便于替换为内存实现（单元测试）或云存储实现。
 */
public interface CsvWriter {

    /**
     * 把文本写入指定文件。
     *
     * @param file    目标文件
     * @param content 待写入内容
     * @throws IOException 目录不可创建或写文件失败时抛出
     */
    void write(File file, String content) throws IOException;
}
