package com.exercise.export;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;

/**
 * CSV 文件写入实现。
 *
 * <p>使用 UTF-8 编码并在文件头写入 BOM，保证 Excel 直接打开时中文不乱码；
 * 目标目录不存在时自动逐级创建。</p>
 */
public class FileCsvWriter implements CsvWriter {

    @Override
    public void write(File file, String content) throws IOException {
        if (file == null) {
            throw new IllegalArgumentException("目标文件不能为空");
        }
        if (content == null) {
            throw new IllegalArgumentException("写入内容不能为空");
        }
        File parent = file.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new IOException("无法创建目录：" + parent.getAbsolutePath());
        }
        try (Writer writer = new OutputStreamWriter(
                new FileOutputStream(file), StandardCharsets.UTF_8)) {
            writer.write('\uFEFF');
            writer.write(content);
        }
    }
}
