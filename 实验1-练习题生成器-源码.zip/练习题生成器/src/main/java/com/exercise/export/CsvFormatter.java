package com.exercise.export;

import java.util.List;

import com.exercise.core.Question;

/**
 * 题目格式化抽象：把题目列表转换为可写入文件的文本。
 * 具体格式（CSV、TXT、Excel）由实现类决定，业务层不感知细节。
 */
public interface CsvFormatter {

    /**
     * 格式化题目网格，单元格内容为“题号. 算式 =”。
     *
     * @param questions     题目列表
     * @param columnsPerRow 每行展示的列数
     * @return 逗号分隔的矩形网格文本
     */
    String format(List<Question> questions, int columnsPerRow);

    /**
     * 格式化答案网格，单元格内容为“题号. 答案”。
     */
    String formatAnswers(List<Question> questions, int columnsPerRow);
}
