package com.exercise.export;

import java.util.List;

import com.exercise.core.Question;

/**
 * CSV 网格格式化实现。
 *
 * <p>输出规则：题目按顺序填满每一行，每行 {@code columnsPerRow} 个单元格，
 * 单元格之间以英文逗号分隔；最后一行题量不足时允许留空，不补占位符。</p>
 */
public class QuestionCsvFormatter implements CsvFormatter {

    private static final String LINE_SEPARATOR = "\n";

    @Override
    public String format(List<Question> questions, int columnsPerRow) {
        return buildGrid(questions, columnsPerRow, true);
    }

    @Override
    public String formatAnswers(List<Question> questions, int columnsPerRow) {
        return buildGrid(questions, columnsPerRow, false);
    }

    private String buildGrid(List<Question> questions, int columnsPerRow, boolean withExpression) {
        if (questions == null) {
            throw new IllegalArgumentException("题目列表不能为空");
        }
        if (columnsPerRow < 1) {
            throw new IllegalArgumentException("每行列数必须大于 0，当前为：" + columnsPerRow);
        }
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < questions.size(); i++) {
            if (i > 0) {
                builder.append(i % columnsPerRow == 0 ? LINE_SEPARATOR : ",");
            }
            Question question = questions.get(i);
            String cell = (i + 1) + ". " + (withExpression
                    ? question.text()
                    : String.valueOf(question.value()));
            builder.append(escape(cell));
        }
        builder.append(LINE_SEPARATOR);
        return builder.toString();
    }

    /**
     * 按 CSV 规范转义：内容中出现逗号、引号或换行时，用双引号包裹并把内部引号加倍。
     */
    private String escape(String cell) {
        if (cell.indexOf(',') >= 0 || cell.indexOf('"') >= 0
                || cell.indexOf('\n') >= 0 || cell.indexOf('\r') >= 0) {
            return '"' + cell.replace("\"", "\"\"") + '"';
        }
        return cell;
    }
}
