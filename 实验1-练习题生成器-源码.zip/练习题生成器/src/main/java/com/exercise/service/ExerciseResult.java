package com.exercise.service;

import java.io.File;
import java.util.List;

/**
 * 一次生成任务的结果快照。
 */
public final class ExerciseResult {

    private final int questionCount;
    private final int columnsPerRow;
    private final File questionFile;
    private final File answerFile;
    private final List<String> previewLines;
    private final long elapsedMillis;

    public ExerciseResult(int questionCount, int columnsPerRow, File questionFile,
                          File answerFile, List<String> previewLines, long elapsedMillis) {
        this.questionCount = questionCount;
        this.columnsPerRow = columnsPerRow;
        this.questionFile = questionFile;
        this.answerFile = answerFile;
        this.previewLines = previewLines;
        this.elapsedMillis = elapsedMillis;
    }

    public int getQuestionCount() {
        return questionCount;
    }

    public int getColumnsPerRow() {
        return columnsPerRow;
    }

    public File getQuestionFile() {
        return questionFile;
    }

    public File getAnswerFile() {
        return answerFile;
    }

    public List<String> getPreviewLines() {
        return previewLines;
    }

    public long getElapsedMillis() {
        return elapsedMillis;
    }
}
