package com.exercise.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.exercise.core.GeneratorConfig;
import com.exercise.core.Question;
import com.exercise.core.QuestionGenerator;
import com.exercise.export.CsvFormatter;
import com.exercise.export.CsvWriter;

/**
 * 业务编排层：串起“生成 → 格式化 → 写出”的流程。
 *
 * <p>三个协作者都通过接口注入（构造器注入），本类不依赖任何具体实现，
 * 是依赖倒转原则在业务层的落地；单元测试可注入内存版的生成器与写入器。</p>
 */
public class ExerciseService {

    private final QuestionGenerator questionGenerator;
    private final CsvFormatter csvFormatter;
    private final CsvWriter csvWriter;

    public ExerciseService(QuestionGenerator questionGenerator, CsvFormatter csvFormatter, CsvWriter csvWriter) {
        this.questionGenerator = Objects.requireNonNull(questionGenerator, "题目生成器不能为空");
        this.csvFormatter = Objects.requireNonNull(csvFormatter, "格式化器不能为空");
        this.csvWriter = Objects.requireNonNull(csvWriter, "写入器不能为空");
    }

    /**
     * 生成练习题并写入 CSV 文件（不生成答案文件）。
     */
    public ExerciseResult generate(GeneratorConfig config, File questionFile) throws IOException {
        return generate(config, questionFile, null);
    }

    /**
     * 生成练习题并写入 CSV 文件，答案文件可选。
     *
     * @param config       生成参数
     * @param questionFile 题目文件
     * @param answerFile   答案文件，传 null 表示不生成答案
     */
    public ExerciseResult generate(GeneratorConfig config, File questionFile, File answerFile) throws IOException {
        Objects.requireNonNull(config, "生成参数不能为空");
        Objects.requireNonNull(questionFile, "题目文件不能为空");
        long start = System.currentTimeMillis();

        List<Question> questions = questionGenerator.generate(config.getQuestionCount());
        String questionContent = csvFormatter.format(questions, config.getColumnsPerRow());
        csvWriter.write(questionFile, questionContent);

        File writtenAnswerFile = null;
        if (answerFile != null) {
            csvWriter.write(answerFile, csvFormatter.formatAnswers(questions, config.getColumnsPerRow()));
            writtenAnswerFile = answerFile;
        }

        List<String> previewLines = new ArrayList<String>();
        String[] lines = questionContent.split("\\R");
        for (int i = 0; i < lines.length && i < 3; i++) {
            if (!lines[i].isEmpty()) {
                previewLines.add(lines[i]);
            }
        }
        return new ExerciseResult(questions.size(), config.getColumnsPerRow(),
                questionFile, writtenAnswerFile, previewLines,
                System.currentTimeMillis() - start);
    }
}
