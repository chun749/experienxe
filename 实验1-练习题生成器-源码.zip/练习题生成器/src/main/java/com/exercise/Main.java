package com.exercise;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.exercise.core.GeneratorConfig;
import com.exercise.core.JavaRandomSource;
import com.exercise.core.Operators;
import com.exercise.core.QuestionFactory;
import com.exercise.core.QuestionGenerator;
import com.exercise.core.RandomQuestionFactory;
import com.exercise.core.RandomSource;
import com.exercise.core.UniqueQuestionGenerator;
import com.exercise.export.CsvFormatter;
import com.exercise.export.CsvWriter;
import com.exercise.export.FileCsvWriter;
import com.exercise.export.QuestionCsvFormatter;
import com.exercise.service.ExerciseResult;
import com.exercise.service.ExerciseService;
import com.exercise.ui.ConsoleInput;

/**
 * 程序入口（界面层）。
 *
 * <p>支持两种运行方式：</p>
 * <ol>
 *   <li>交互模式：直接双击或执行 java 命令，按提示逐步输入参数；</li>
 *   <li>命令行模式：{@code java com.exercise.Main 题量 列数 文件路径 [true|false]}，
 *       便于批量生成与自动化演示。</li>
 * </ol>
 */
public final class Main {

    private static final String DEFAULT_FILE_NAME = "练习题.csv";

    private Main() {
    }

    public static void main(String[] args) {
        printBanner();
        try {
            if (args.length >= 3) {
                runBatch(args);
            } else {
                runInteractive();
            }
        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println();
            System.out.println("[错误] " + e.getMessage());
        } catch (IOException e) {
            System.out.println();
            System.out.println("[错误] 文件读写失败：" + e.getMessage());
        }
    }

    /**
     * 交互模式：按提示输入参数，可连续生成多份练习卷。
     */
    private static void runInteractive() {
        ConsoleInput input = new ConsoleInput();
        System.out.println("规则说明：每道题由三个正整数和两个运算符组成，");
        System.out.println("操作数、中间结果与最终结果都必须为 1~99 的整数，除法必须整除。");
        System.out.println();

        boolean again = true;
        while (again) {
            int count = input.readInt("请输入题目数量（1~" + GeneratorConfig.MAX_QUESTION_COUNT + "，回车默认 30）：",
                    1, GeneratorConfig.MAX_QUESTION_COUNT, 30);
            int columns = input.readInt("请输入每行展示的列数（1~" + GeneratorConfig.MAX_COLUMNS + "，回车默认 5）：",
                    1, GeneratorConfig.MAX_COLUMNS, 5);
            String path = input.readText("请输入题目 CSV 文件路径（回车默认 " + DEFAULT_FILE_NAME + "）：", DEFAULT_FILE_NAME);
            boolean withAnswers = input.readYesNo("是否同时生成答案文件？(Y/n，回车默认 Y）：", true);

            File questionFile = new File(path);
            if (questionFile.exists() && !input.readYesNo("文件已存在，是否覆盖？(y/N，回车默认 N）：", false)) {
                System.out.println("已取消本次生成。");
            } else {
                File answerFile = withAnswers ? buildAnswerFile(questionFile) : null;
                try {
                    ExerciseResult result = createService().generate(
                            new GeneratorConfig(count, columns), questionFile, answerFile);
                    printResult(result);
                } catch (IOException e) {
                    System.out.println("[错误] 文件写入失败：" + e.getMessage());
                } catch (RuntimeException e) {
                    System.out.println("[错误] 生成失败：" + e.getMessage());
                }
            }
            again = input.readYesNo("是否继续生成另一份练习卷？(y/N，回车默认 N）：", false);
        }
        System.out.println("程序结束，感谢使用！");
    }

    /**
     * 命令行模式：java com.exercise.Main 题量 列数 文件路径 [是否生成答案]
     */
    private static void runBatch(String[] args) throws IOException {
        int count = Integer.parseInt(args[0]);
        int columns = Integer.parseInt(args[1]);
        File questionFile = new File(args[2]);
        boolean withAnswers = args.length >= 4 && Boolean.parseBoolean(args[3]);
        File answerFile = withAnswers ? buildAnswerFile(questionFile) : null;

        ExerciseResult result = createService().generate(new GeneratorConfig(count, columns), questionFile, answerFile);
        printResult(result);
    }

    /**
     * 组装业务对象。所有依赖都通过接口串联，便于日后替换实现。
     */
    private static ExerciseService createService() {
        RandomSource randomSource = new JavaRandomSource();
        QuestionFactory questionFactory = new RandomQuestionFactory(
                randomSource, Operators.all(), GeneratorConfig.MIN_VALUE, GeneratorConfig.MAX_VALUE, 1000);
        QuestionGenerator generator = new UniqueQuestionGenerator(questionFactory);
        CsvFormatter formatter = new QuestionCsvFormatter();
        CsvWriter writer = new FileCsvWriter();
        return new ExerciseService(generator, formatter, writer);
    }

    private static File buildAnswerFile(File questionFile) {
        String name = questionFile.getName();
        int dot = name.lastIndexOf('.');
        String prefix = dot < 0 ? name : name.substring(0, dot);
        String suffix = dot < 0 ? "" : name.substring(dot);
        return new File(questionFile.getParentFile(), prefix + "_答案" + suffix);
    }

    private static void printResult(ExerciseResult result) {
        System.out.println();
        System.out.println("生成成功：共 " + result.getQuestionCount() + " 道题，每行 " + result.getColumnsPerRow()
                + " 列，耗时 " + result.getElapsedMillis() + " 毫秒。");
        System.out.println("题目文件：" + result.getQuestionFile().getAbsolutePath());
        if (result.getAnswerFile() != null) {
            System.out.println("答案文件：" + result.getAnswerFile().getAbsolutePath());
        }
        System.out.println("内容预览（前 3 行）：");
        List<String> preview = result.getPreviewLines();
        for (String line : preview) {
            System.out.println("  " + line);
        }
        System.out.println();
    }

    private static void printBanner() {
        System.out.println("==========================================================");
        System.out.println("        四则运算练习题生成器  ExerciseGen v1.0");
        System.out.println("        软件构造实验一：练习题代码设计及编写");
        System.out.println("==========================================================");
    }
}
