@echo off
set PATH=%SystemRoot%\System32;%SystemRoot%;%PATH%
chcp 936 >nul
mode con: cols=100 lines=26
title ExerciseGen - Batch Generate
cd /d "%~dp0"
cls
"C:\Program Files\Java\jdk1.8.0_111\bin\java.exe" -cp out com.exercise.Main 30 5 "out\��ϰ��.csv" true
ping -n 20 127.0.0.1 >nul